

from xml.dom.expatbuilder import InternalSubsetExtractor

# function to find intersection
def itsec(crick,badm):
    result=[]
    for i in crick:
        if i in badm:
            result.append(i)
    print("\nStudents Who Plays Cricket And Badminton : ",len(result),"::",result)

# function to find difference between sets
def diff(crick,badm):
    result=[]
    for i in crick:
        if i not in badm:
            result.append(i)
    for j in badm:
        if j not in crick:
            result.append(j)
    print("\nStudents Who Plays either Cricket or Badminton : ",len(result),"::",result)
        
# 
def neither(crick,badm,footb):
    result=[]
    union=[]
    for i in crick:
        union.append(i)
    for i in badm:
        if i not in union:
            union.append(i)
    for j in footb:
        if j not in union:
            result.append(j)
    print("\nno of Students Who Plays neither Cricket nor Badminton : ",len(result),"::",result)
        
def crick_n_foot(crick,badm,footb):
    intersec=[]
    for i in crick:
        if i in footb:
            intersec.append(i)
    for j in badm:
        if j in intersec:
            intersec.remove(j)
    print("\nno of Students Who Plays Cricket and football but no badminton: ",len(intersec),"::",intersec)
    
            
n1=int(input("enter number of students that plays cricket = "))
A=[]
for i in range(n1):
    a=int(input("Enter roll number = "))
    A.append(a)
    
n2=int(input("Enter number of students that plays Badminton = "))
B=[]
for i in range(n2):
    b=int(input("Enter roll number = "))
    B.append(b)

n3=int(input("Enter number of students that plays Football = "))
C=[]
for i in range(n3):
    c=int(input("Enter roll number = "))
    C.append(c)
    
    
print("\nStudents who plays cricket are ",A)
print("\nStudents who plays badminton are ",B)
print("\nStudents who plays football are ",C)

itsec(A,B)
diff(A,B)
neither(A,B,C)
crick_n_foot(A,B,C)