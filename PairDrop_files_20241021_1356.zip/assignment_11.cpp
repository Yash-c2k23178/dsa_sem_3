// Queues are  frequently  used  in  computer  programming,  and  a  typical example  is  the  creation  of  a
// job  queue  by  an  operating  system.  If  the operating system does not use priorities, then the jobs are
// processed in the order they enter the system. Write C++program for simulating job queue. Write functions
// to add job and delete job from queue.

#include <iostream>
using namespace std;
class Node
{
private:
    char job;
    Node *next;
    friend class Queue;

public:
    Node(char job)
    {
        this->job = job;
        next = nullptr;
    }
    // ~Node();
};
class Queue
{
private:
    Node *head;
    Node *last;
    int n;

public:
    Queue()
    {
        last = head = nullptr;
    }
    bool empty()
    {
        return head == nullptr;
    }
    void enqueue(char job)
    {
        Node *tmp = new Node(job);
        if (!head)
        {
            last = head = tmp;
            tmp->next = nullptr;
            n--;
            return;
        }
        last->next = tmp;
        last = last->next;
        n--;
    }
    char peek()
    {
        if (empty())
        {
            return -1;
        }
        return head->job;
    }

    char dqueue()
    {
        if (empty())
        {
            return -1;
        }
        char ch = head->job;
        Node *tmp = head;
        head = head->next;
        delete tmp;
        return ch;
    }
    void display()
    {
        cout << endl;
        cout << "QUEUE :: " << endl;

        Node *ptr = head;
        if (empty())
        {
            cout << "Empty queue!!!!!!!" << endl;
        }

        while (ptr != nullptr)
        {
            cout << ptr->job << " ";
            ptr = ptr->next;
        }
        cout << endl;
    }
    ~Queue()
    {
        while (head != nullptr)
        {
            Node *ptr = head;
            head = head->next;
            delete ptr;
        }
    }
};
int main()
{
    Queue q;
    char check = 'n';
    do
    {
        int choice;
        cout << "1.for checking if queue is empty \n2.for enqueue job \n3.for delete job \n4.for peek job \n5.for display queue" << endl;
        cout << "CHOICE :: ";
        cin >> choice;
        switch (choice)
        {
        case 1:
            if (q.empty())
            {
                cout << "EMpty!!!!" << endl;
            }
            else
            {
                cout << "NOT Empty!!!" << endl;
            }
            break;
        case 2:
            cout << "Enter JOB :: ";
            char job;
            cin >> job;
            q.enqueue(job);
            goto end;
        case 3:
            cout << "job" << q.dqueue() << " is deleted !!!!!" << endl;
            goto end;
        case 4:
            cout << "peek job is ::" << q.peek();
            goto end;
        case 5:
            q.display();
            goto end;
        }
    end:
        cout << "\n\n Want to do one more operation(y/n) :: ";
        cin >> check;
    } while (check == 'y');
    return 0;
}