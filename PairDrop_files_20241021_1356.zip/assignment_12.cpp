// Write program to implement a priority queue in C++ using an inorder list to store the items in the queue.
// Create a class that includes the data items (which should  be  template)  and  the  priority  (which
// should  be int).  The  inorder  list should contain these objects, with operator <= overloaded so that
// the items with highest priority appear at the beginning of the list (which will make it relatively
// easy to retrieve the highest item.)
#include <iostream>
using namespace std;
template <typename T>
class Node
{
public:
    T value;
    int priority;
    bool operator<=(Node &obj)
    {
        return priority <= obj.priority;
    }
};

class Pq
{
private:
    Node<int> *pque;
    int size = -1;
    int first = -1;
    int n;

public:
    Pq(int n);
    void enqueue(int x, int prio)
    {
        if (size > n)
        {
            cout << "Queue is full !!!!!!!!" << endl;
            return;
        }
            size++;
            pque[size].value = x;
            pque[size].priority = prio;

    }
    int peek();
    void dqueue();
    void display();
    bool empty() { return size == -1 ? 1 : 0; }
    ~Pq();
};

Pq::Pq(int n)
{
    this->n = n;
    pque = new Node<int>[n];
}

int Pq::peek()
{
    int index = -1;
    int prio = INT16_MIN;
    for (int i = 0; i <= size; i++)
    {
        if (prio == pque[i].priority && pque[index].value < pque[i].value)
        {
            prio = pque[i].priority;
            index = i;
        }
        else if (prio < pque[i].priority)
        {
            prio = pque[i].priority;
            index = i;
        }
    }
    if (index == -1)
    {
        return -1;
    }
    return pque[index].value;
}
void Pq::dqueue()
{
    int index = -1;
    int prio = INT16_MIN;
    for (int i = 0; i <= size; i++)
    {
        if (prio == pque[i].priority && pque[index].value < pque[i].value)
        {
            prio = pque[i].priority;
            index = i;
        }
        else if (prio < pque[i].priority)
        {
            prio = pque[i].priority;
            index = i;
        }
    }
    if (index == -1)
    {
        cout << "Queue was Empty so nothing deleted";
        return;
    }

    cout << "Element with value : " << pque[index].value << " and priority : " << pque[index].priority << " is deleted " << endl;
    pque[index].value = -1;
    pque[index].priority = -1;
}

void Pq::display()
{
    cout << "Priority Queue is :--" << endl;
    for (int i = 0; i <= size; i++)
    {
        cout << pque[i].value << "(" << pque[i].priority << ")"
             << " ";
    }
    cout << endl;
}
Pq::~Pq()
{
    for (int i = 0; i < n; i++)
    {
        pque[i].value = -1;
        pque[i].priority = -1;
    }
}

int main()
{
    cout << "Enter size of priority queue : ";
    int n;
    cin >> n;
    Pq q(n);
    char check = 'n';
    do
    {
        int choice;
        cout << "1.for checking if queue is empty \n2.for enqueue element \n3.for delete element \n4.for peek element \n5.for display queue" << endl;
        cout << "CHOICE :: ";
        cin >> choice;

        if (choice == 1)
        {
            if (q.empty())
            {
                cout << "EMpty!!!!" << endl;
            }
            else
            {
                cout << "NOT Empty!!!" << endl;
            }
        }
        else if (choice == 2)
        {
            cout << "Enter Element :: ";
            int chh;
            cin >> chh;
            cout << "Enter priority : ";
            int prio;
            cin >> prio;
            q.enqueue(chh, prio);
        }
        else if (choice == 3)
        {
            q.dqueue();
        }
        else if (choice == 4)
        {
            cout << "peek Element is ::" << q.peek();
        }
        else
        {
            q.display();
        }

        cout << "\n\n Want to do one more operation(y/n) :: ";
        cin >> check;
    } while (check == 'y');
}