"""Write  a Python program  to  store  second  year  percentage  of  students  in array.  Write  function  for  sorting  array  of  floating-point  numbers  in ascending order using a) Insertion sort and b) Shell Sortand display top five scores"""


class Student:
    def __init__(self, n):
        self.n = n
        self.scores = []

    def get_data(self):
        for i in range(self.n):
            a = float(input(f"Enter SGPA {i+1} student : "))
            if a <= 10 and a > 0:
                self.scores.append(a)
            else:
                print("wrong input !!!!")
                a = float(input(f"Enter SGPA {i+1} student : "))
                self.scores.append(a)
        print("\n SGPA list : ", self.scores)

    def ins_sort(self):
        for i in range(1, self.n):
            key = self.scores[i]
            j = i-1
            while(self.scores[j] < key and j >= 0):
                self.scores[j+1] = self.scores[j]
                j -= 1
            self.scores[j+1] = key
        
        print("\nsorted SGPA list using insertion sort : ",self.scores)

    def shell_sort(self):
        gap = self.n//2
        while(gap > 0):
            for i in range(gap, self.n):
                j = i-1
                key = self.scores[i]
                while(j >= 0 and self.scores[j] < key):
                    self.scores[j+1] = self.scores[j]
                    j -= 1
                self.scores[j+1] = key
            gap = gap//2
        print("\nsorted SGPA list using shell sort: ",self.scores)

    def top_five(self):
        print("\nTop Five students are : \n")
        for i in range(5):
            print(self.scores[i])


s = Student(8)
s.get_data()
s.shell_sort()
s.ins_sort()
s.top_five()
