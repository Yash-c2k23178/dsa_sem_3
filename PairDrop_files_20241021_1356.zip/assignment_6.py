"""Write a Python program to store first year percentage of students in array. Write  function  for  sorting  array  of  floating-point  numbers  in  ascending order using Quick sortand display top five scores."""

def partition(array, low, high):
    pivot = array[high]
    i = low-1
    for j in range(low, high):
        if array[j] <= pivot:
            i += 1
            (array[i], array[j]) = (array[j], array[i])
    (array[i+1], array[high]) = (array[high], array[i+1])

    return i+1


def quick_sort(arr, low, high):

    if (low < high):
        pi = partition(arr, low, high)
        quick_sort(arr, low, pi-1)
        quick_sort(arr, pi+1, high)
        


class Student:
    def __init__(self, n):
        self.n = n
        self.scores = []

    def get_data(self):
        for i in range(self.n):
            a = float(input(f"Enter SGPA {i+1} student : "))
            if a <= 10 and a >= 5:
                self.scores.append(a)
            else:
                print("wrong input !!!! or failed ")
                a = float(input(f"Enter SGPA {i+1} student : "))
                self.scores.append(a)
        print("\n SGPA list : ", self.scores)

    def qsort(self):
        quick_sort(self.scores, 0, len(self.scores)-1)
        print("\nquick qsort : ", self.scores)

    def top_five(self):
        print("\nTop Five students are : \n")
        for i in range(self.n-1, self.n-1-5, -1):
            print(self.scores[i])


n = int(input("Enter number of student : "))
s = Student(n)
s.get_data()
s.qsort()
s.top_five()
