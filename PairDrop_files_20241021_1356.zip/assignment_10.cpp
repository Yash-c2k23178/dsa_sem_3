// Implement C++program  for  expression  conversion  as  infix  to  postfix  and  its evaluation using stack
// based on given conditions:
// 1. Operands and operator, both must be single character.
// 2. Input Postfix expression must be in a desired format.
// 3. Only '+', '-', '*' and '/ ' operators are expected.
#include <iostream>
using namespace std;
class Node
{
private:
    char oprnd;
    Node *next;
    friend class stack;

public:
    Node(int oprnd);
};

Node::Node(int oprnd)
{
    this->oprnd = oprnd;
    this->next = nullptr;
}

class stack
{
private:
    Node *head;

public:
    stack();
    void push(char x);
    void pop();
    char top();
    bool isempty() { return head == nullptr; };
    ~stack();
};

stack::stack()
{
    head = nullptr;
}

void stack::push(char x)
{
    Node *ptr = new Node(x);
    ptr->next = head;
    head = ptr;
}

void stack::pop()
{
    if (isempty())
        return;
    Node *ptr = head;
    head = head->next;
    delete ptr;
}
char stack ::top()
{
    if (isempty())
    {
        return '0';
    }
    return head->oprnd;
}
stack::~stack()
{
    while (head != nullptr)
    {
        Node *ptr = head->next;
        delete head;
        head = ptr;
    }
}

bool isdigit(char ch)
{
    if (ch - '0' >= 0 && ch - '0' <= 9)
    {
        return true;
    }
    return false;
}

int preferance(char op)
{
    if (op == '+' || op == '-')
    {
        return 1;
    }
    else if (op == '*' || op == '/')
    {
        return 2;
    }
    else if (op == '^')
    {
        return 3;
    }
    return 0;
}

bool isOperator(char c)
{
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

int pow(int n1, int n2)
{
    if (n2 == 0)
    {
        return 1;
    }
    return n1 * pow(n1, n2 - 1);
}
string infixToPostfix(string infix)
{
    stack st;
    string postfix = "";

    for (char c : infix)
    {
        if (isalnum(c))
        {
            postfix += c;
        }
        else if (c == '(')
        {
            st.push(c);
        }
        else if (c == ')')
        {
            while (!st.isempty() && st.top() != '(')
            {
                postfix += st.top();
                st.pop();
            }
            st.pop();
        }
        else if (isOperator(c))
        {
            while (!st.isempty() && preferance(c) <= preferance(st.top()))
            {
                postfix += st.top();
                st.pop();
            }
            st.push(c);
        }
    }

    while (!st.isempty())
    {
        postfix += st.top();
        st.pop();
    }
    return postfix;
}
int evaluate_postfix(string post)
{
    stack st;
    int result = 0;
    for (int i = 0; i < post.length(); i++)
    {
        char ch=post[i];
        // cout<<st.top()<<" ";
        if (isdigit(ch))
        {
            st.push(post[i]);
        }
        else if(isOperator(ch))
        {
            int dig2 = st.top() - '0';
            // cout<<st.top()<<endl;
            st.pop();
            int dig1 = st.top() - '0';
            // cout<<st.top()<<endl;
            st.pop();
            switch (ch)
            {
            case '+':
                result = dig1 + dig2;
                st.push('0' + result);
                break;

            case '-':
                result = dig1 - dig2;
                st.push('0' + result);
                break;

            case '*':
                result = dig1 * dig2;
                st.push('0' + result);
                break;

            case '/':
                result = dig1 / dig2;
                st.push('0' + result);
                break;

            case '^':
                result = pow(dig1, dig2);
                st.push('0' + result);
                break;

            default:
                break;
            }
            // cout<<st.top()<<endl;
        }
    }
    return st.top() - '0';
}
int main()
{
    string s;
    cout << "Enter valid infix Expression :: ";
    cin >> s;
    cout << "Postfix of given expression is :: ";
    cout << infixToPostfix(s) << endl
         << endl;
    cout << "Solved Value Of PostFix is ::";
    cout << evaluate_postfix(infixToPostfix(s)) << endl;
}