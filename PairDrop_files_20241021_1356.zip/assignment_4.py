"""a) Write a Python program to store roll numbers of student in array who
attended training program in random order. Write function for searching
whether particular student attended training program or not, using Linear
search and Sentinel search.
b) Write a Python program to store roll numbers of student array who attended
training program in sorted order. Write function for searching whether
particular student attended training program or not, using Binary search and
Fibonacci search."""


class Training:
    def __init__(self, n):
        self.num = n
        self.attend = []

    def set_data(self):
        for i in range(self.num):
            self.attend.append(
                int(input(f"Enter roll number of {i+1} student : ")))
        

    def get_data(self):
        print("Roll numbers of students who attended sesion are : ", self.attend)
        self.attend.sort()
        print("Sorted Roll numbers of students who attended sesion are : ", self.attend)

    def linear(self, x):
        is_present = False
        for i in self.attend:
            if(i == x):
                return self.attend.index(i)
        return "absent"

    def sentinel(self, x):
        last = self.attend[self.num-1]
        self.attend[self.num-1] = x
        i = 0
        while(self.attend[i] != x):
            i += 1
        self.attend[self.num-1] = last
        if(i < (self.num-1) or self.attend[self.num-1] == x):
            return i
        return "absent"

    def binary(self, x):
        self.attend.sort()
        high = self.num-1
        low = 0
        while(low <= high):
            mid = int((high+low)/2)
            if self.attend[mid] == x:
                return mid
            elif self.attend[mid] < x:
                low = mid+1
            else:
                high = mid-1
        return "absent"

    def fibo(self, x):
        self.attend.sort()
        fib2 = 0
        fib1 = 1
        fib = fib2+fib1
        while fib < self.num:
            fib2 = fib1
            fib1 = fib
            fib = fib2+fib1

        offset = -1

        while fib > 1:
            i = min(offset+fib2, self.num-1)

            if x > self.attend[i]:
                fib = fib1
                fib1 = fib2
                fib2 = fib-fib1
                offset = i
            elif x < self.attend[i]:
                fib = fib2
                fib1 = fib1-fib2
                fib2 = fib-fib1
            else:
                return i

        if fib1 and self.attend[offset+1] == x:
            return offset+1
        return "absent"


a = int(input(f"Enter number of students that attended training session : "))
m = Training(a)
m.set_data()
m.get_data()
x = int(input("Enter roll number of student whos attendence is to be checked : "))
print("using linear search : ", m.linear(x))
print("using sentinel search : ", m.sentinel(x))
print("using binary search : ", m.binary(x))
print("using fibonacci search : ", m.fibo(x))
