# Write a Python program to compute following computation on matrix:
# a) Addition of two matrices
# b) Subtraction of two matrices
# c) Multiplication of two matrices
# d) Transpose of a matrix 
class Matrix:

    def __init__(self,r,c):
        self.row=r
        self.column=c
        self.mat=[]
    
    def set_mat(self):
        for i in range(self.row):
            temp=[]
            for j in range(self.column):
                temp.append(int(input(f"Enter element at {i+1}{j+1} ")))
            self.mat.append(temp)

    def get_mat(self):
        # temp=[]
        for i in self.mat:
            print(i)
    
    def add(self,other):
        if(self.row!=other.row or self.column!=other.column):
            return "!!!!! For addition no of rows and columns of both matrices must be same !!!!!"
        tmp=[]
        for i in range(self.row):
            row=[]
            for j in range(self.column):
                row.append(self.mat[i][j]+other.mat[i][j])
            tmp.append(row)
        return tmp

    def sub(self,other):
        if(self.row!=other.row or self.column!=other.column):
            return "!!!!! For subtraction no of rows and columns of both matrices must be same !!!!!"
        tmp=[]
        for i in range(self.row):
            row=[]
            for j in range(self.column):
                row.append(self.mat[i][j]-other.mat[i][j])
            tmp.append(row)
        return tmp
    
    def multiply(self,other):
        if(self.column!=other.row ):
            return "!!!!! For multiplication no of columns of 1st matrix must equal to no of rows of 2nd!!!!!"
        tmp=[]
        for i in range(self.row):
            row=[]
            for k in range(other.column):
                ele=0
                for j in range(self.column):
                    ele+=self.mat[i][j]*other.mat[j][k]
                row.append(ele)
            tmp.append(row)
        return tmp

    def transpose(self):
        trans=[]
        for i in range(self.column):
            row=[]
            for j in range(self.row):
                row.append(self.mat[j][i])
            trans.append(row)
        return trans
        



m=Matrix(2,4)
m2=Matrix(4,3)
print("first matrix : \n")
m.set_mat()
m.get_mat()
print("second matrix:\n")
m2.set_mat()
m2.get_mat()
add=m.add(m2)
sub=m.sub(m2)
mult=m.multiply(m2)
trsps=m.transpose()
print("addition is : ")
for i in add:
    print(i)
print(f"\nsubtraction is : ")
for i in sub:
    print(i)
print("\nmultiplication is : ")
for i in mult:
    print(i)
print("\ntranspose of m is :")
for i in trsps:
    print(i)