// A double-ended queue (deque) is a linear list in which additions and deletions may be
// made at either end. Obtain a data representation mapping a deque into a one-
// dimensional array. Write C++ program to simulate deque with functions to add and
// delete elements from either end of the deque.

#include <iostream>
using namespace std;
// template <typename T>
class Node
{
public:
    int value;
    Node *next;
    Node *prev;
    Node(int x)
    {
        value = x;
        next = nullptr;
        prev = nullptr;
    }
};

class deque
{
private:
    Node *head;
    Node *last;
    int n;

public:
    deque();
    void push_front(int);
    void push_back(int);
    // int peek();
    void pop_front();
    void pop_back();
    void display();
    bool empty() { return !head ? 1 : 0; }
    ~deque();
};

deque::deque()
{
    head = nullptr;
    last = nullptr;
}

void deque ::push_front(int x)
{
    Node *temp = new Node(x);
    temp->next = head;
    head->prev = temp;
    head = temp;
}
void deque::push_back(int x)
{
    if (!head)
    {
        head = new Node(x);
        last = head;
        return;
    }
    Node *ptr = head;
    while (ptr->next)
    {
        ptr = ptr->next;
    }
    Node *temp = new Node(x);
    ptr->next = temp;
    temp->prev = ptr;
    last = temp;
}
void deque::pop_front()
{
    if (!head)
    {
        cout << "deque is empty !!!";
        return;
    }
    if (last == head)
    {
        last = nullptr;
    }
    Node *ptr = head;
    head = head->next;
    cout<<"Element with value "<<ptr->value<<" is deleted "<<endl;
    delete ptr;
}

void deque::pop_back()
{
    if (!last)
    {
        cout<<"empty!!"<<endl;
        return;
    }
    
    if (head == last)
    {
        delete head;
        last=nullptr;
        return;
    }
    Node *ptr = last;
    last = last->prev;
    last->next=nullptr;
    cout<<"Element with value "<<ptr->value<<" is deleted "<<endl;
    delete ptr;  
}

void deque::display()
{
    if (!head)
    {
        cout<<"deque is empty !!!"<<endl;
        return;
    }
    
    Node *ptr = head;
    while (ptr != nullptr)
    {
        cout << ptr->value << " ";
        ptr=ptr->next;
    }
    cout << endl;
}
deque::~deque()
{
    Node *ptr = nullptr;
    while (head != nullptr)
    {
        ptr = head->next;
        delete head;
        head = ptr;
    }
}

int main()
{
    deque q;
    char check = 'n';
    do
    {
        int choice;
        cout << "1.for checking if queue is empty \n2.for push element \n3.for pop element from front \n4.for pop element from back \n5.for display queue" << endl;
        cout << "CHOICE :: ";
        cin >> choice;

        if (choice == 1)
        {
            if (q.empty())
            {
                cout << "EMpty!!!!" << endl;
            }
            else
            {
                cout << "NOT Empty!!!" << endl;
            }
        }
        else if (choice == 2)
        {
            cout << "Enter Element :: ";
            int chh;
            cin >> chh;
            q.push_back(chh);
        }
        else if (choice == 3)
        {
            q.pop_front();
        }
        else if (choice == 4)
        {
            q.pop_back();
        }
        else
        {
            q.display();
        }

        cout << "\n\n Want to do one more operation(y/n) :: ";
        cin >> check;
    } while (check == 'y');
}