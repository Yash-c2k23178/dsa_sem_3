// In any language program mostly syntax error occurs due to unbalancing delimiter
// such  as  (),  {},  [].  Write C++program  using stack to
// check whether given expression is well parenthesized or not.

#include <iostream>
using namespace std;
class Node
{
private:
    char val;
    Node *next;
    friend class stack;

public:
    Node();
    Node(char val);
    ~Node();
};
Node::Node()
{
    this->val = 'N';
    next = nullptr;
}
Node::Node(char val)
{
    this->val = val;
    next = nullptr;
}

Node::~Node()
{
    delete next;
}

class stack : public Node
{
private:
    Node *head;

public:
    stack();
    ~stack();
    void push(char x);
    void pop();
    char top();
    bool isempty() { return head == nullptr; };
};

stack::stack()
{
    head = nullptr;
}

stack::~stack()
{
    Node *ptr = head;
    while (ptr != nullptr)
    {
        Node *ptr2 = ptr->next;
        delete ptr;
        ptr = ptr2;
    }
}

void stack::push(char x)
{
    Node *ptr = new Node(x);
    ptr->next = head;
    head = ptr;
}
void stack::pop()
{
    if (isempty())
        return;
    Node *ptr = head;
    head = head->next;
    delete ptr;
}
char stack::top()
{
    if (isempty())
    {
        return 'N';
    }
    return head->val;
}

bool iswellpwrenthesis(string test)
{
    stack st;

    for (int i = 0; i < test.length(); i++)
    {
        if (test[i] == '(' || test[i] == '{' || test[i] == '[')
        {
            st.push(test[i]);
        }
        else if (test[i] == ')' || test[i] == '}' || test[i] == ']')
        {
            if (st.isempty())
            {
                return false;
            }
            char top = st.top();
            if ((test[i] == ')' && top == '(') || (test[i] == '}' && top == '{') || (test[i] == ']' && top == '['))
            {
                st.pop();
            }
            else
            {
                return false;
            }
        }
    }
    if (st.top() == 'N')
    {
        return true;
    }
    return false;
}
int main()
{
    string sample;
    cout << "Enter string that should be checked : ";
    cin >> sample;
    if (iswellpwrenthesis(sample))
    {
        cout << "string " << sample << " is well parenthesised..." << endl;
    }
    else
    {
        cout << "\n\n!!!!  string \"" << sample << "\" is NOT well parenthesised..." << endl;
    }
}