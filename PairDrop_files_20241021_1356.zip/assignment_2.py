'''Write a Python program to compute following operations on String:
a) To display word with the longest length
b) To determines the frequency of occurrence of particular character in
the string
c) To check whether given string is palindrome or not
d) To display index of first appearance of the substring
e) To count the occurrences of each word in a given string'''


from random import sample


class String:
    def __init__(self,sample):
        self.sample=sample
        
    # function to get longest string 
    def longest(self):
        str1=self.sample.split(" ")
        ans=""
        for i in str1:
            if len(i)>len(ans):
                ans=i
        print(f"\nLongest string from given input is : {ans}\n")

    # function to check occurence of specific character
    def Occurence(self):
        self.char=str(input("\nEnter character to check its occurrence : "))
        print(f"\ncharacter {self.char} occurs {self.sample.count(self.char)} times \n")
    
    # function to check palindrome 
    def is_palindrome(self,s):
        reverse=s[::-1]
        if(reverse==s):
            print(f"string '{s}' is palindrome.\n")
        else:
            print(f"string '{s}' is not palindrome.\n")

    # function to get first appearance of sub string
    def Appear(self):
        substr=str(input("\nEnter substring to check : "))
        print(f"\nFirst appearance of '{substr}' is at position {self.sample.find(substr)}\n")

    # function to check occurence of each word from string 
    def Each_word_occurs(self):
        str_list=self.sample.split(" ")
        str_list=set(str_list)
        for i in str_list:
            print(f"Occurence of string '{i}' is {self.sample.count(i)}\n")

s=str(input("Enter string :"))
s1=String(s)
s1.longest()
s1.Occurence()
sr=str(input("Enter string for checking palindrome :  "))
s1.is_palindrome(sr)
s1.Appear()
s1.Each_word_occurs()