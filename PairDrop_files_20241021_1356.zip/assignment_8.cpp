// Second year Computer Engineering class, set A of students like Vanilla Ice-cream and set B of students
// like butterscotch ice-cream.
//  Write C++program to store two sets using linked list. compute and display-
// a) Set of students who like both vanilla and butterscotch
// b) Set of students who like either vanilla or butterscotch or not both
// c) Number of students who like neither vanilla nor butterscotch

#include <iostream>
using namespace std;
class comp_class;
class Node
{
    string data;
    Node *next;

public:
    Node()
    {
        data = "No entry";
        next = nullptr;
    }
    Node(string data)
    {
        this->data = data;
        next = nullptr;
    }
    friend class comp_class;
};

class comp_class
{
    Node *headA;
    Node *headB;
    int n;

public:
    comp_class(int n)
    {
        this->n = n;
        headA = nullptr;
    }
    void get_data_in_setA()
    {
        cout << "Enter No of students who likes Vanilla Ice-cream :";
        int nA;
        cin >> nA;
        cout << "Enter (1) student Name :";
        string s;
        cin >> s;
        headA = new Node(s);
        Node *ptr = headA;
        for (int i = 1; i < nA; i++)
        {
            cout << "Enter (" << i + 1 << ") student Name :";
            cin >> s;
            Node *temp = new Node(s);
            ptr->next = temp;
            ptr = ptr->next;
        }
    }
    void get_data_in_setB()
    {
        cout << "Enter No of students who likes Butterscotch Ice-cream :";
        int nB;
        cin >> nB;
        cout << "Enter (1) student Name :";
        string s;
        cin >> s;
        headB = new Node(s);
        Node *ptr = headB;
        for (int i = 1; i < nB; i++)
        {
            cout << "Enter (" << i + 1 << ") student Name :";
            cin >> s;
            Node *temp = new Node(s);
            ptr->next = temp;
            ptr = ptr->next;
        }
    }

    void likes_Both()
    {
        int n = 0;
        Node *ptr1 = headA;
        cout << "Students Who likes Both Ice-Creams : ";
        cout << "{"
             << " ";
        while (ptr1 != nullptr)
        {
            Node *ptr2 = headB;
            while (ptr2 != nullptr)
            {
                if (ptr1->data == ptr2->data)
                {
                    n++;
                    cout << ptr2->data << ",";
                }

                ptr2 = ptr2->next;
            }

            ptr1 = ptr1->next;
        }
        cout << " "
             << "}" << endl;
        cout << "No of students who likes both Vanilla Ice-cream and Butterscotch Ice-cream : " << n << endl;
        this->n = this->n - n;
    }

    void likes_either()
    {
        int n = 0;
        Node *ptr1 = headA;
        cout << "Students Who likes either Vanilla or Butterscotch Ice-Cream  : ";
        cout << "{"
             << " ";
        while (ptr1 != nullptr)
        {
            bool ch = false;
            Node *ptr2 = headB;
            while (ptr2 != nullptr)
            {
                if (ptr1->data == ptr2->data)
                {
                    ch = true;
                }

                ptr2 = ptr2->next;
            }
            if (!ch)
            {
                cout << ptr1->data << ",";
                n++;
            }
            ptr1 = ptr1->next;
        }

        ptr1 = headB;
        while (ptr1 != nullptr)
        {
            bool ch = false;
            Node *ptr2 = headA;
            while (ptr2 != nullptr)
            {
                if (ptr1->data == ptr2->data)
                {
                    ch = true;
                }

                ptr2 = ptr2->next;
            }
            if (!ch)
            {
                cout << ptr1->data << ",";
                n++;
            }
            ptr1 = ptr1->next;
        }
        cout << " "
             << "}" << endl;
        cout << "No of students who likes either Vanilla Ice-cream or Butterscotch Ice-cream : " << n << endl;
        this->n = this->n - n;
    }
    void remain()
    {
        cout << "Students Who likes neither Vanilla nor Butterscotch Ice-Cream : " << n << endl;
    }
    ~comp_class()
    {
        Node *temp = headA;
        Node *tmp;
        do
        {
            tmp = temp->next;
            delete temp;
            temp = tmp;
        } while (temp != nullptr);
        temp = headB;
        do
        {
            tmp = temp->next;
            delete temp;
            temp = tmp;
        } while (temp != nullptr);
    }
};

int main()
{
    cout << "Enter Total Number Of Students :  ";
    int n;
    cin >> n;
    comp_class C2(n);
    C2.get_data_in_setA();
    C2.get_data_in_setB();
    C2.likes_Both();
    C2.likes_either();
    C2.remain();
}