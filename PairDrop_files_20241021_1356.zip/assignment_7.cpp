// The  ticket  booking  system  of  Cinemax  theatre  has  to  be  implemented using C++program. There are
// 10 rows and 7 seats in each row. Doubly circular  linked  list has to be  maintained  to  keep  track
// of free  seats  at rows.  Assume  some  random  booking  to  start  with.  Use  array  to  store pointers
// (Head pointer)to each row. On demand a) The list of available seats is to be displayed b) The seats are to
// be  booked c) The booking can be cancelled.

// OR

// Write C++program for storing binary number using doubly
// linked  lists. Write functions-a) To compute 1‘s and 2‘s complement b) Add two binary numbers

#include <iostream>
using namespace std;
class Theater;
class Seat
{
private:
    Seat *prev;
    int avail;
    Seat *next;
    friend Theater;

public:
    Seat()
    {
        avail = 0;
        prev = next = this;
    }
    ~Seat() {}
};

class Theater
{
private:
    Seat *start;
    Seat **arr;

public:
    Theater();
    void Book();
    void cancel();
    void display();
    ~Theater();
};

Theater::Theater()
{
    arr = new Seat *[10];
    // theater has 70 seats
    start = new Seat;
    Seat *temp = start;
    arr[0] = start;
    for (int i = 1; i < 70; i++)
    {
        Seat *Nseat = new Seat;
        if (i % 7 == 0)
        {
            arr[i / 7] = Nseat;
        }
        Nseat->prev = temp;
        Nseat->next = start;
        temp->next = Nseat;
        start->prev = Nseat;
        temp = temp->next;
    }
}

Theater::~Theater()
{
    Seat *temp = start;
    Seat *tmp;
    do
    {
        tmp = temp->next;
        delete temp;
        temp = tmp;
    } while (temp != start);
    delete[] arr;
}

void Theater::display()
{
    cout << "\t\t\t\t######################################################--ABHIRUCHI_THEATER--######################################################" << endl
         << endl
         << endl;
    Seat *temp = start;
    cout << "\t\t\t\t\t\t\t\t -----------------------------SCREEN----------------------------" << endl
         << endl
         << endl;
    for (int i = 0; i < 10; i++)
    {
        if (i != 9)
        {
            cout << "\t\t\t\t\t\t\t"
                 << "Row:0" << i + 1 << "----->     ";
        }
        else
        {
            cout << "\t\t\t\t\t\t\t"
                 << "Row:" << i + 1 << "----->     ";
        }

        for (int j = 0; j < 7; j++)
        {
            cout << "__" << temp->avail << "__"
                 << "  ";
            temp = temp->next;
        }
        if (i == 1 || i == 7)
        {
            cout << endl;
        }

        cout << endl;
    }
    cout << endl
         << endl;
}
void Theater::Book()
{
    cout << "\nTHERE ARE TOTAL 10 ROWS AND EACH ROW HAS 7 SEATS..." << endl;
    int x, y;
    try
    {
        cout << "Enter Row and Seat number space separated : ";
        cin >> x >> y;
        if (x < 1 || x > 10 || y < 1 || y > 7 || cin.fail())
        {
            throw 0;
        }
    }
    catch (...)
    {
        cout << "\nXXXXXXX Invalid position OR Invalid input for type int XXXXXXX" << endl;
    }
    Seat *temp = arr[x - 1];
    for (int i = 1; i < y; i++)
    {
        temp = temp->next;
    }
    if (temp->avail==1)
    {
        cout<<"!!!!!! Seat is already booked choose another seat or row !!!!!!"<<endl;
        return;
    }
    
    temp->avail = 1;
    cout << "!!!!!!! SEAT BOOKED !!!!!!!" << endl
         << endl
         << endl;
}
void Theater::cancel()
{
    int x, y;
    try
    {
        cout << "Enter Row and Seat number space separated : ";
        cin >> x >> y;
        if (x < 1 || x > 10 || y < 1 || y > 7 || cin.fail())
        {
            throw 0;
        }
    }
    catch (...)
    {
        cout << "\nXXXXXXX Invalid position OR Invalid input for type int XXXXXXX" << endl;
    }
    
    Seat *temp = arr[x - 1];
    for (int i = 1; i < y; i++)
    {
        temp = temp->next;
    }
    if (temp->avail==0)
    {
        cout<<"!!!! Seat had not been booked you can not cancel it !!!!"<<endl;
        return;
    }
    
    temp->avail = 0;
    cout << "!!!!!!! SEAT CANCELED !!!!!!!" << endl
         << endl
         << endl;
}
int main()
{
    Theater T;
    T.display();
    char ch='n';
    do
    {
        cout<<"1.for booking\n2.for cancel\n3.for display\n\n";
        cout<<"Enter choice : ";
        int n;
        cin>>n;
        switch (n)
        {
        case 1:
            T.Book();
            break;
        case 2:
            T.cancel();
            break;
        case 3:
            T.display();
            break;
        default:
            cout<<" !!!!wrong choice !!!!"<<endl<<endl;
            break;
        } 
        cout<<"\nwant to continue : ";
        cin>>ch;
    } while (ch=='y');
    return 0;
}